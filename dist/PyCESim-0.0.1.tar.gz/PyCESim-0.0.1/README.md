# PyCESim
Python package for the classical simulation of Coulomb explosion
