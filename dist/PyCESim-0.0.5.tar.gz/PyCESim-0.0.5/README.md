# PyCESim
Python package for the classical simulation of Coulomb explosion. Can be installed through cloning this repository and installing locally (e.g. with pip or running setup.py) or from PyPi:

  pip install PyCESim

Find documentation [here](https://htmlpreview.github.io/?https://github.com/f-allum/PyCESim/blob/main/docs/_build/html/index.html)
