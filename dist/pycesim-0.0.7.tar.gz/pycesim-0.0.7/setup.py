from setuptools import setup, find_packages

VERSION = '0.0.7' 
DESCRIPTION = 'PyCESim - classical simulation of Coulomb explosion'

setup(
        name="PyCESim", 
        version=VERSION,
        author="Felix Allum",
        author_email="felix.allum@desy.de",
        description=DESCRIPTION,
        packages=find_packages(),
        install_requires=['cclib', 'numpy', 'matplotlib', 'scipy', 'pandas'],
        url='https://github.com/f-allum/PyCESim/',
        keywords=['Coulomb explosion']
)